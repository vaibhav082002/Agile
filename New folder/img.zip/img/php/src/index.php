<!DOCTYPE html>
<html>
<head>
    <title>House Price Prediction</title>
    <meta charset="UTF-8">
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/water.css@2/out/water.min.css">
</head>
<body>

    <h1>House Price Prediction</h1>

<form class="process-form.php" method="post">
	<h2>Area (Square Feet)</h2>
    <input class="area"  type="text" id="uiSqft" class="floatLabel" name="Squareft" value="1000">
	<h2>BHK</h2>
	<div class="switch-field">
		<input type="radio" id="radio-bhk-1" name="uiBHK" value="1"/>
		<label for="radio-bhk-1">1</label>
		<input type="radio" id="radio-bhk-2" name="uiBHK" value="2" checked/>
		<label for="radio-bhk-2">2</label>
		<input type="radio" id="radio-bhk-3" name="uiBHK" value="3"/>
		<label for="radio-bhk-3">3</label>
		<input type="radio" id="radio-bhk-4" name="uiBHK" value="4"/>
		<label for="radio-bhk-4">4</label>
		<input type="radio" id="radio-bhk-5" name="uiBHK" value="5"/>
		<label for="radio-bhk-5">5</label>
	</div>
	</form>
<form class="form">
	<h2>Bath</h2>
	<div class="switch-field">
		<input type="radio" id="radio-bath-1" name="uiBathrooms" value="1"/>
		<label for="radio-bath-1">1</label>
		<input type="radio" id="radio-bath-2" name="uiBathrooms" value="2" checked/>
		<label for="radio-bath-2">2</label>
		<input type="radio" id="radio-bath-3" name="uiBathrooms" value="3"/>
		<label for="radio-bath-3">3</label>
		<input type="radio" id="radio-bath-4" name="uiBathrooms" value="4"/>
		<label for="radio-bath-4">4</label>
		<input type="radio" id="radio-bath-5" name="uiBathrooms" value="5"/>
		<label for="radio-bath-5">5</label>
	</div>
		<h2>Location</h2>
	<div>
  <select class="location" name="" id="uiLocations">
    <option value="" disabled="disabled" selected="selected">Choose a Location</option>
		<option>Electronic City</option>
        <option>Rajaji Nagar</option>
  </select>
</div>
	<button class="submit" onclick="onClickedEstimatePrice()" type="button">Estimate Price</button>
	<div id="uiEstimatedPrice" class="result">	<h2></h2> </div>
</body>
</html>        
